﻿from pydlshogi.usi.usi import *
from pydlshogi.player.mcts_player import *

player = MCTSPlayer()
usi(player)
