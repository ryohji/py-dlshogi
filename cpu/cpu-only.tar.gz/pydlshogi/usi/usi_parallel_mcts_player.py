﻿from pydlshogi.usi.usi import *
from pydlshogi.player.parallel_mcts_player import *

player = ParallelMCTSPlayer()
usi(player)
