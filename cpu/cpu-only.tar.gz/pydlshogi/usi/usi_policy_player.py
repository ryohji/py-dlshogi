﻿from pydlshogi.usi.usi import *
from pydlshogi.player.policy_player import *

player = PolicyPlayer()
usi(player)
