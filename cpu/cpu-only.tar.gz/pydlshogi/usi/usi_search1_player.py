﻿from pydlshogi.usi.usi import *
from pydlshogi.player.search1_player import *

player = Search1Player()
usi(player)
