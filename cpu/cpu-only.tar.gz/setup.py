﻿import setuptools

setuptools.setup(
    name = 'python-dlshogi',
    version = '0.0.1',
    author = '',
    packages = ['pydlshogi'],
    scripts = [],
)
